import React from 'react'

function blog() {
  return (
    <div>blog</div>
  )
}

export default blog