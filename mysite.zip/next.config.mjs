/** @type {import('@/data/node_modules/next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
};

export default nextConfig;
